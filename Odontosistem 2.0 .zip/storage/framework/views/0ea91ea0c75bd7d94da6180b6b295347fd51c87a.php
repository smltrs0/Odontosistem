<?php $__env->startSection('content'); ?>
<div class="row ">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">Todos los pacientes</div>

            <div class="card-body">
                <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
                <?php endif; ?>
                <table class="table table-bordered show" id="tabla-pacientes">
                    <thead>
                        <tr>
                            <th width="30">No</th>
                            <th><?php echo e(__('Full name')); ?></th>
                            <th><?php echo e(__('Phone')); ?></th>
                            <th><?php echo e(__('Address')); ?></th>
                            <th width="210px">Acción</th>
                        </tr>
                    </thead>
                   <tbody>
                   <?php $__currentLoopData = $pacientes ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                           <td><?php echo e(++$i); ?></td>
                           <td>
                               <a href="<?php echo e(route('pacientes.show',$paciente->id)); ?>"><?php echo e($paciente->name." ".$paciente->secont_name." ".$paciente->last_name." ".$paciente->second_last_name); ?></a>
                           </td>
                           <td><?php echo e($paciente->phone); ?></td>
                           <td><?php echo e($paciente->address); ?></td>
                           <td>
                               <form action="<?php echo e(route('pacientes.destroy',$paciente->id)); ?>" method="POST">

                                   <a class="btn btn-info" title="Ver datos del paciente" href="<?php echo e(route('pacientes.show',$paciente->id)); ?>"><i class="pe-7s-note2"> </i></a>

                                   <a href="#" class="btn btn-success" title="Ver citas medicas del paciente"><i class="pe-7s-news-paper"></i></a>

                                   <a class="btn btn-primary" title="Editar datos de este paciente" href="<?php echo e(route('pacientes.edit',$paciente->id)); ?>"><i class="fa fa-edit"></i></a>
                                   <?php echo csrf_field(); ?>
                                   <?php echo method_field('DELETE'); ?>

                                   <button type="submit" title="Eliminar este paciente" onclick="return confirm('Estas seguro de que deceas eliminar este paciente?')" class="btn btn-danger"><i class="pe-7s-trash"></i></button>
                               </form>
                           </td>
                       </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                </table>
                <?php echo $pacientes ?? ''->links(); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Odontosistem\resources\views/pacientes/index.blade.php ENDPATH**/ ?>