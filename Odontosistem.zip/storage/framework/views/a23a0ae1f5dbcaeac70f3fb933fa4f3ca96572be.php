<div class="mt-3 ml-3 mr-3" style="z-index: 10;">
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert" style="z-index: 10">

            <?php echo e(session('success')); ?>


        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning" role="alert" style="z-index: 10">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <?php echo e(session('warning')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-error" role="alert" style="z-index: 10">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger" style="z-index: 10">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp-php7.2\htdocs\Odontosistem\resources\views/partials/alerts.blade.php ENDPATH**/ ?>