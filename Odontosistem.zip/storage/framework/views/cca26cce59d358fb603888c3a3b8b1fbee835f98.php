<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Editar paciente'); ?>

<?php
$mysql_result = [
    "event_id" => 11492,     // ID del paciente
    "name" => "Samuel Trias",  // Nombre del paciente
    "showsPrimary" => false,   // Dientes de leche, si es true existen
    "comments" => "Este es un comentario de prueba desde un json",
    "procedures" => '[{"tooth":22,"pro":82,"title":"Resina preventiva buena","side":false, "type": "Completado"},
          {"tooth":23,"pro":99,"title":"Superficie Cariada","side":"center", "type": "Pendiente"}
          ]',
];
?>
<div class="row ">
    <div class="col-md-12">
        <div class="card mb-5">
            <div class="card-header text-center">
                <div>Editar paciente</div>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('pacientes.update', $paciente->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <nav class="mb-4">
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-datos-personales-tab" data-toggle="tab"
                               href="#nav-datos-personales" role="tab" aria-controls="nav-datos-personales"
                               aria-selected="true">Datos personales</a>
                            <a class="nav-item nav-link" id="nav-antecedentes-tab" data-toggle="tab"
                               href="#nav-antecedentes" role="tab" aria-controls="nav-antecedentes"
                               aria-selected="false">Anamnesis
                                                     general</a>
                            <a class="nav-item nav-link" id="nav-odontograma-tab" data-toggle="tab"
                               href="#nav-odontograma"
                               role="tab" aria-controls="nav-odontograma" aria-selected="false">Odontograma</a>
                        </div>
                    </nav>
                    <!--Final de las pestañas-->

                    <div class="tab-content mt-1" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-datos-personales" role="tabpanel"
                             aria-labelledby="nav-datos-personales-tab">
                            <?php echo $__env->make('pacientes.__formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                        <!--Final de datos personales-->
                        <div class="tab-pane fade" id="nav-antecedentes" role="tabpanel"
                             aria-labelledby="nav-antecedentes-tab">
                            <div class="form-gropu">
                                <label for="motivo-consulta">Primer motivo consulta</label>
                                <textarea class="form-control" name="motivo-consulta" id="motivo-consulta"></textarea>
                            </div>
                            <div class="form-row mt-1">
                                <div class="col">
                                    <label for="antecedentes-m">Antecedentes Médicos:</label>
                                    <textarea class="form-control" name="antecedentes" id="antecedentes-m">
                                        <?php if($paciente->antecedentes): ?>
                                            <?php $__currentLoopData = json_decode($paciente->antecedentes); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $antecedente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($antecedente.","); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?></textarea>
                                </div>
                                <div class="col">
                                    <label for="alergias">Alergias</label>
                                    <textarea class="form-control" name="alergias" id="alergias">
                                        <?php if($paciente->alergias): ?>
                                            <?php $__currentLoopData = json_decode($paciente->alergias); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alergia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($alergia.", "); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </textarea>
                                </div>
                            </div>
                            <div class="form-row mt-1">
                                <div class="col">
                                    <label for="medicamentos">Medicamentos en uso</label>
                                    <textarea class="form-control" name="medicamentos" id="medicamentos"></textarea>
                                </div>
                                <div class="col">
                                    <label for="habitos">Hábitos</label>
                                    <textarea class="form-control" name="habitos" id="habitos">
                                        <?php if($paciente->habitos): ?>
                                            <?php $__currentLoopData = json_decode($paciente->habitos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($habito.", "); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?></textarea>
                                </div>
                            </div>
                            <div class="form-row mt-1">
                                <div class="col">
                                    <label for="antecedentes-f">Antecedentes familiares</label>
                                    <textarea class="form-control" name="antecedentes-f" id="antecedentes-f"></textarea>
                                </div>
                                <div class="col">
                                    <label for="otros">Otros</label>
                                    <textarea class="form-control" name="otros"
                                              id="otros"><?php echo e($paciente->otros); ?></textarea>
                                </div>
                            </div>
                            <div class="form-row mt-2">
                                <div class="col">
                                    <label for="peso">Peso (kgs):</label>
                                    <input id="peso" class="form-control" type="text">
                                </div>
                                <div class="col">
                                    <label for="altura">Altura (cms):</label>
                                    <input id="altura" class="form-control" type="text">
                                </div>
                            </div>
                            <div class="form-row mt-4">
                                <div class="col-md-4">
                                    <label for="embaraso">¿Paciente Embarazada?</label>
                                    <div id="embaraso">
                                        <label class="radio-inline">
                                            <input type="radio" name="embarazada" value="1">Si</label>
                                        <label class="radio-inline">
                                            <input type="radio" name="embarazada" value="0" checked="">No</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <label>¿Ha presentado problemas de Coagulación?</label>
                                    <div>
                                        <label class="radio-inline">
                                            <input type="radio" name="coagulacion" value="1">Si</label>
                                        <label class="radio-inline">
                                            <input type="radio" name="coagulacion" value="0" checked="">No</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <label>¿Ha presentado problemas con Anestésicos Locales?</label>
                                    <div>
                                        <label class="radio-inline">
                                            <input type="radio" name="anestesicos" value="1">Si</label>
                                        <label class="radio-inline">
                                            <input type="radio" name="anestesicos" value="0" checked="">No</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--Final de antecedentes-->
                        <div class="tab-pane fade" id="nav-odontograma" role="tabpanel"
                             aria-labelledby="nav-odontograma-tab">
                            <?php echo $__env->make('pacientes.__odontogram', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-sm btn-primary btn-block">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>




    <script type="text/javascript">
        $(document).ready(function () {
            //START THE ODONTOGRAM
            const odontogram = new Odontogram();

            $.ajax({
                type: "GET",
                url: "<?php echo e(asset('./assets/scripts/odontograma/procedures.json')); ?>", // Get all procedures
                success: function (initialProcedures) {
                    odontogram.procedures = initialProcedures;
                    odontogram.config = <?= json_encode($mysql_result); ?>;

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Status: " + textStatus);
                    alert("Error: " + errorThrown);
                }
            });
        })


    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('odontograma'); ?>
    <!--Odontograma-->
        <link href="<?php echo e(asset('css/odontogram.css')); ?>" rel="stylesheet"/>
        <script type="text/javascript" src="<?php echo e(asset('assets/scripts/odontograma/vendor.bundle.base.js')); ?>"></script>
    <!--chard.js-->
        <script type="text/javascript" src="<?php echo e(asset('assets/scripts/odontograma/odontogram.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-php7.2\htdocs\Odontosistem\resources\views/pacientes/editar.blade.php ENDPATH**/ ?>