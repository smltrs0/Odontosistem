
<?php $__env->startSection('content'); ?>

    <div class="mb-3">
        <div class="card">
            <div class="card-header">Mis citas</div>
            <div class="card-body">
                <?php if(!$existe): ?>
                   <div class="alert alert-warning text-center">
                       <p>Antes de crear una cita, es necesario que completes los datos de tu perfil</p>
                       <a href="<?php echo e(route('mi-cuenta.index')); ?>" class="btn btn-primary">Agregar datos de mi cuenta</a>
                   </div>
                <?php else: ?>
                <?php if($citas->count() == 0): ?>
                    <div class="alert alert-warning text-center">
                        No tienes ninguna cita.
                    </div>
                <?php endif; ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $citas ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elemento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Fecha :<?php echo e($elemento->fecha); ?> Hora <?php echo e($elemento->hora); ?>

                            <div>
                                <a href="<?php echo e(route('citas.edit',$elemento->id)); ?>"
                                   class="badge badge-primary badge-pill mb-1" title="Editar cita">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('citas.destroy', $elemento->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="badge badge-danger badge-pill"
                                            onclick="return confirm('Estas seguro de que deceas eliminar esta cita?')"
                                            type="submit" title="Eliminar cita">
                                        <i class="fa fa-trash"></i></button>
                                </form>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </div>

            <!-- Modal -->
            <div class="modal fade" id="ModalCitas" role="dialog" aria-labelledby="ModalCitaLabel"
                 data-backdrop="false">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="ModalCitaLabel">Crear cita</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(route('citas.store')); ?>" method="POST" id="elForm">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="cita-fecha">Fecha</label>
                                    <input id="cita-fecha" class="form-control" min="" type="date" name="fecha"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label for="cita-hora">Hora</label>
                                    <input class="form-control" type="time" name="hora" id="cita-hora">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" id="elSubmit" class="btn btn-primary">Crear</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mt-1">
            <!-- Boton disparador del modal -->
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalCitas">
                Crear cita
            </button>
        </div>
        <?php endif; ?>
    </div>

    <script>
        var fecha = new Date();
        var anio = fecha.getFullYear();
        var dia = fecha.getDate();
        var _mes = fecha.getMonth(); //viene con valores de 0 al 11
        _mes = _mes + 1; //ahora lo tienes de 1 al 12
        if (_mes < 10) //ahora le agregas un 0 para el formato date
        {
            var mes = "0" + _mes;
        } else {
            var mes = _mes.toString;
        }
        document.getElementById("cita").min = anio + '-' + mes + '-' + dia;


    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Odontosistem\resources\views/calendar/citas.blade.php ENDPATH**/ ?>