
<?php $__env->startSection('content'); ?>
    <div class="mb-3">
        <div class="card">
            <div class="card-header">Modificar procedimiento</div>
            <div class="card-body">
               <form method="POST" action="<?php echo e(route('procedures.update', $procedimiento->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?> 

                   <div class="form-group">
                       <label for="">Nombre</label>
                    <input class="form-control" type="text" name="title" value="<?php echo e($procedimiento->title); ?>">
                   </div>
                   <div class="form-group">
                       <label for="">Tecla</label>
                    <input class="form-control" type="text" name="key_p" value="<?php echo e($procedimiento->key_p); ?>">
                   </div>
                   <div class="form-group">
                       <label for="">Codigo</label>
                    <input class="form-control" type="text" name="code" value="code">
                   </div>
                   <div class="form-group">
                    <label for="">Precio</label>
                 <input class="form-control" type="text" name="price" value="<?php echo e($procedimiento->price); ?>">
                </div>
                   <div class="form-group">
                           <label for="type">Tipo</label>
                           <select id="type" class="form-control" name="type" value="type">
                               <option value="">[Seleccione]</option>
                               <option value="pendiente">Pendiente</option>
                               <option value="completado">Completado</option>
                           </select>
                   </div>
                   <div class="form-group">
                       <label for="">Estilo a aplicar</label>
                    <input class="form-control" type="text" name="className">
                   </div>
               
             
            <div class="card-footer">
                <a href="#" onclick="history.back()" class="btn btn-danger btn-sm">Cancelar</a>
                <input class="btn btn-success" type="submit">
            </div>
            </form>
           
        </div>
        
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-php7.2\htdocs\Odontosistem\resources\views/procedures/actualizar.blade.php ENDPATH**/ ?>