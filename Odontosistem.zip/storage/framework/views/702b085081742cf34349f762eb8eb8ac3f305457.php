<?php $__env->startSection('content'); ?>
    <div class="container -body-block pb-5">
        <div class="card">
            <div class="card-header">
                Respaldo de la base de datos
            </div>
            <div class="card-body">
                <a href="<?php echo e(url('backup/create')); ?>" class="btn btn-danger" title="Crear nuevo backup">
                    <i class="fa fa-plus" aria-hidden="true"></i> Crear nuevo respaldo
                </a>

                <div class="py-4"></div>
                <?php echo $__env->make('backup.backups-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="py-3"></div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Odontosistem\resources\views/backup/backups.blade.php ENDPATH**/ ?>