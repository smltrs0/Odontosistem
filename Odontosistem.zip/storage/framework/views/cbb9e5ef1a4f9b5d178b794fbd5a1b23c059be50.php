<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://unpkg.com/fullcalendar@5.1.0/main.min.css">
    <script src="https://unpkg.com/fullcalendar@5.1.0/main.min.js"></script>
    <script src="https://unpkg.com/fullcalendar@5.1.0/locales-all.js"></script>
<div class="mb-3">
        <div class="card">
            <div class="card-header">Citas para hoy</div>
                <div class="card-body">
                  <ul class="list-group">

                          <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                          <li class="list-group-item"><?php echo e($cita->fecha); ?>  <a class="align-content-end" href="<?php echo e(route
                          ('pacientes.show',$cita->paciente_id)); ?>">Ver paciente</a></li>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
        </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Odontosistem\resources\views/calendar/index.blade.php ENDPATH**/ ?>