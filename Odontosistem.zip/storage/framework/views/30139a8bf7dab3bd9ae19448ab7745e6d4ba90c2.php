<?php $__env->startSection('content'); ?>
    <div class="mb-3">
        <div class="card">
            <div class="card-header">Todas las citas</div>
            <div class="card-body">
                    <table class="table">
                        <tr>
                                <th width="50%">Nombre</th>
                                <th width="30%">Estado</th>
                                <th width="20%">accion</th>
                            </tr>


                            <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                   <?php echo e($fechaCita = date( 'd-m-Y' ,strtotime($cita->fecha))); ?>

                                </td>
                                <td>
                                    <a href="#" title="Ver cita cita">Atendido </a>
                                    <?php if(date('d-m-Y',strtotime(now())) == $fechaCita): ?>
                                        <span class="badge badge-primary">
                                            Hoy
                                        </span>
                                    <?php endif; ?>
                                </td>
                                   <td>
                                       <a class="align-content-end" href="<?php echo e(route('pacientes.show',$cita->paciente_id)); ?>">Ver paciente</a>
                                   </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
            </div>
            <div class="card-footer d-flex justify-content-end">
                <?php echo e($citas->links()); ?>

            </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-php7.2\htdocs\Odontosistem\resources\views/calendar/index.blade.php ENDPATH**/ ?>