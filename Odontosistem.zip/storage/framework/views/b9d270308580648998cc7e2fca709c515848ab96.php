<?php $__env->startSection('content'); ?>
<div class="row ">
    <div class="col-md-12">
        <div class="card mb-1">
            <div class="card-header">Agregar nuevo paciente</div>

            <div class="card-body">
                <form action="<?php echo e(route('pacientes.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="registered_by" value="<?php echo e(Auth::user()->id); ?>" hidden>
                    <?php echo $__env->make('pacientes.__formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <button class="btn btn-primary" name="crear-paciente">Cear nuevo paciente</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-php7.2\htdocs\Odontosistem\resources\views/pacientes/agregar.blade.php ENDPATH**/ ?>