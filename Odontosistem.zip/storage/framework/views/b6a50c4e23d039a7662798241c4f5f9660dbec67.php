
<?php $__env->startSection('content'); ?>

    <div class="mb-3">
        <div class="card">
            <div class="card-header">Procedimientos</div>
            <div class="card-body">
                <a href="<?php echo e(route('procedures.create')); ?>" class="btn btn-primary mb-2">Crear procedimiento</a>
               
                <?php if(false): ?>
                    <div class="alert alert-warning text-center">
                        No tienes ningun procedimiento registrado.
                    </div>
                <?php endif; ?>
                
           
                
                <table class="table table-hover table-sm">
                    <tr>
                        <td>Code</td>
                        <td>Costo</td>
                        <td>Nombre</td>
                        <td>type</td>
                        <td width=" 15%">Acción</td>
                    </tr>
                    <?php $__currentLoopData = $procedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($procedure->code); ?></td>
                        <td><?php echo e($procedure->price); ?></td>
                        <td><?php echo e($procedure->title); ?></td>
                        <td><?php echo e($procedure->type); ?></td>
                        <td> <a href="<?php echo e(route('procedures.edit',$procedure->id)); ?>" class="btn btn-warning btn-sm text-white">
                            <span class="fa fa-edit"></span></a> 
                            <a href="<?php echo e(route('procedures.destroy',$procedure->id)); ?>" class="btn btn-sm btn-danger"><span class="fa fa-trash-alt"></span></a>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

            </div>
            <div class="card-footer">
                <?php echo e($procedimientos->links()); ?>

            </div>

           
        </div>
        
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-php7.2\htdocs\Odontosistem\resources\views/procedures/index.blade.php ENDPATH**/ ?>